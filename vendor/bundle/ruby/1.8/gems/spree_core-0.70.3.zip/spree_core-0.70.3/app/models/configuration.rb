class Configuration < ActiveRecord::Base

end