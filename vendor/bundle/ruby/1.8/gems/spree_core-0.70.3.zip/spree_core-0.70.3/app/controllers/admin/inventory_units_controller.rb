class Admin::InventoryUnitsController < Admin::BaseController
end