class Admin::ShippingCategoriesController < Admin::ResourceController
end
