//= require jquery
//= require jquery_ujs
//= require jquery.validate/jquery.validate.min
//= require store/checkout
//= require store/product
//= require store/cart
