class Admin::ConfigurationsController < Admin::BaseController
end
