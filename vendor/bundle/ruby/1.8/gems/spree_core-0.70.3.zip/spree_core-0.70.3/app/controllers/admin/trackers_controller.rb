class Admin::TrackersController < Admin::ResourceController
end
