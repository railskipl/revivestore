Factory.define(:taxonomy) do |record|
  record.name "Brand"
end
