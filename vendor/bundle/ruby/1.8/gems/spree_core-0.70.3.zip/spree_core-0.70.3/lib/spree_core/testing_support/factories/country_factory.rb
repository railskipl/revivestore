Factory.define :country do |f|
  f.iso_name 'UNITED STATES'
  f.name 'UNITED STATES'
  f.iso 'US'
  f.iso3 'USA'
  f.numcode 840
end
