Factory.define :mail_method do |f|
  f.environment { Rails.env }
  f.active true
end
