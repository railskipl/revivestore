Factory.define :configuration do |f|
  f.name "Default Configuration"
  f.type "app_configuration"
end
