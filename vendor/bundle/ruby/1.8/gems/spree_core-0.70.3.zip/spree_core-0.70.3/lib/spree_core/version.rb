module Spree
  def self.version
    "0.70.3"
  end
end
