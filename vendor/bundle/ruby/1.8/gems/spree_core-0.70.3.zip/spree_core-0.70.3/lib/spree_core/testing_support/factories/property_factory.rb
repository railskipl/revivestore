Factory.define :property do |f|
  f.name 'baseball_cap_color'
  f.presentation 'cap color'
end
