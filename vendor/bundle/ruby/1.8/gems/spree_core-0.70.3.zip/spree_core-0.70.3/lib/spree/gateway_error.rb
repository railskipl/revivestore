module Spree
  class GatewayError < RuntimeError; end
end