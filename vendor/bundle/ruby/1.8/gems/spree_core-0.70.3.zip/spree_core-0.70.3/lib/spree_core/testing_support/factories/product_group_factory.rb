Factory.define :product_group do |f|
  f.name 'sports'
end
