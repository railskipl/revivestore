Core
====

Core e-commerce functionality for the Spree project


Testing
-------

Create the test site

    bundle exec rake test_app

Run the tests

    bundle exec rake spec

Run the coverage. After the rake task open coverage/index.html

    bundle exec rake rcov

