class SpreePaypalWebsiteStandardHooks < Spree::ThemeSupport::HookListener
  # custom hooks go here
  # insert_before :checkout_summary_box, 'checkout/paypal_checkout'
end